import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Role, AuthState } from '../types';

interface Store extends AuthState {
  users: User[];
  roles: Role[];
  setUsers: (users: User[]) => void;
  setRoles: (roles: Role[]) => void;
  addUser: (user: User) => void;
  addRole: (role: Role) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  updateRole: (id: string, role: Partial<Role>) => void;
  deleteUser: (id: string) => void;
  deleteRole: (id: string) => void;
  login: (email: string, password: string) => void;
  logout: () => void;
}

export const useStore = create<Store>()(
  persist(
    (set) => ({
      users: [],
      roles: [],
      isAuthenticated: false,
      user: null,
      error: null,
      setUsers: (users) => set({ users }),
      setRoles: (roles) => set({ roles }),
      addUser: (user) => set((state) => ({ users: [...state.users, user] })),
      addRole: (role) => set((state) => ({ roles: [...state.roles, role] })),
      updateUser: (id, updatedUser) =>
        set((state) => ({
          users: state.users.map((user) =>
            user.id === id ? { ...user, ...updatedUser } : user
          ),
        })),
      updateRole: (id, updatedRole) =>
        set((state) => ({
          roles: state.roles.map((role) =>
            role.id === id ? { ...role, ...updatedRole } : role
          ),
        })),
      deleteUser: (id) =>
        set((state) => ({
          users: state.users.filter((user) => user.id !== id),
        })),
      deleteRole: (id) =>
        set((state) => ({
          roles: state.roles.filter((role) => role.id !== id),
        })),
      login: (email, password) =>
        set((state) => {
          const user = state.users.find(
            (u) => u.email === email && u.password === password && u.status === 'active'
          );
          if (user) {
            return {
              isAuthenticated: true,
              user,
              error: null,
            };
          }
          return {
            isAuthenticated: false,
            user: null,
            error: 'Invalid email or password',
          };
        }),
      logout: () =>
        set({
          isAuthenticated: false,
          user: null,
          error: null,
        }),
    }),
    {
      name: 'vrv-security-store',
      partialize: (state) => ({
        isAuthenticated: state.isAuthenticated,
        user: state.user,
        users: state.users,
        roles: state.roles,
      }),
    }
  )
);