export type Permission = 'read' | 'write' | 'delete' | 'manage';

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  roleId: string;
  status: 'active' | 'inactive';
  lastLogin: string;
  createdAt: string;
  password?: string; // Added for authentication
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  error: string | null;
}