import { Header } from './components/Header';
import { UserList } from './components/UserList';
import { RoleList } from './components/RoleList';
import { LoginForm } from './components/LoginForm';
import { useEffect } from 'react';
import { useStore } from './store/useStore';

// Mock data with passwords for testing
const mockUsers = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john@vrvsecurity.com',
    password: 'admin123', // In a real app, this would be hashed
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    roleId: 'admin',
    status: 'active',
    lastLogin: '2024-03-10T10:00:00Z',
    createdAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane@vrvsecurity.com',
    password: 'user123', // In a real app, this would be hashed
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    roleId: 'user',
    status: 'active',
    lastLogin: '2024-03-09T15:30:00Z',
    createdAt: '2024-01-15T00:00:00Z',
  },
];

const mockRoles = [
  {
    id: 'admin',
    name: 'Administrator',
    description: 'Full system access with all permissions',
    permissions: ['read', 'write', 'delete', 'manage'],
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'user',
    name: 'Standard User',
    description: 'Basic access with limited permissions',
    permissions: ['read'],
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
];

function App() {
  const { users, setUsers, setRoles, isAuthenticated } = useStore();

  useEffect(() => {
    // Only initialize mock data if there are no users yet
    if (users.length === 0) {
      setUsers(mockUsers);
      setRoles(mockRoles);
    }
  }, [users.length, setUsers, setRoles]);

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <UserList />
          <RoleList />
        </div>
      </main>
    </div>
  );
}

export default App;