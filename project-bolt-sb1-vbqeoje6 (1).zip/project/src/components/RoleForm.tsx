import { useState } from 'react';
import { Role, Permission } from '../types';
import { useStore } from '../store/useStore';

interface RoleFormProps {
  role?: Role;
  onClose: () => void;
}

const AVAILABLE_PERMISSIONS: Permission[] = ['read', 'write', 'delete', 'manage'];

export function RoleForm({ role, onClose }: RoleFormProps) {
  const { addRole, updateRole } = useStore();
  const [formData, setFormData] = useState<Partial<Role>>(
    role ?? {
      name: '',
      description: '',
      permissions: ['read'],
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (role) {
      updateRole(role.id, formData);
    } else {
      addRole({
        ...formData,
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      } as Role);
    }
    onClose();
  };

  const togglePermission = (permission: Permission) => {
    const permissions = formData.permissions ?? [];
    if (permissions.includes(permission)) {
      setFormData({
        ...formData,
        permissions: permissions.filter((p) => p !== permission),
      });
    } else {
      setFormData({
        ...formData,
        permissions: [...permissions, permission],
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Name</label>
        <input
          type="text"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          rows={3}
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Permissions</label>
        <div className="space-y-2">
          {AVAILABLE_PERMISSIONS.map((permission) => (
            <label key={permission} className="flex items-center">
              <input
                type="checkbox"
                checked={formData.permissions?.includes(permission)}
                onChange={() => togglePermission(permission)}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="ml-2 text-sm text-gray-700 capitalize">{permission}</span>
            </label>
          ))}
        </div>
      </div>
      <div className="flex justify-end space-x-3 pt-4">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-500"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
        >
          {role ? 'Update' : 'Create'} Role
        </button>
      </div>
    </form>
  );
}